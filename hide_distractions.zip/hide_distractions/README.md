# P000280SE Completion of Focus Bear Chrome Extension

## How to run

(Make sure dev mode is enabled in Chrome Extensions tab)

1. cd hide_distractions
2. npm install
3. npm run build

## Trouble shooting

ls dist/

1. rm -rf dist
2. npm run build
